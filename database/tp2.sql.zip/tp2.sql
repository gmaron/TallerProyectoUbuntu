-- phpMyAdmin SQL Dump
-- version 4.2.12deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 14, 2015 at 11:14 AM
-- Server version: 5.6.25-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tp2`
--
CREATE DATABASE IF NOT EXISTS `tp2` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tp2`;

-- --------------------------------------------------------

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
CREATE TABLE IF NOT EXISTS `auditoria` (
`id` int(11) NOT NULL,
  `fechaEntrada` varchar(255) NOT NULL,
  `fechaSalida` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auditoria`
--

INSERT INTO `auditoria` (`id`, `fechaEntrada`, `fechaSalida`, `email`) VALUES
(1, '15:41 - 13/10/2015', '15:41 - 13/10/2015', 'miltonmeroni@gmail.com'),
(2, '15:57 - 13/10/2015', '15:08 - 13/10/2015', 'gastonmaron@gmail.com'),
(3, '16:13 - 13/10/2015', '15:49 - 13/10/2015', 'ppsgalileo@gmail.com'),
(4, '15:49 - 13/10/2015', '15:49 - 13/10/2015', 'miltonmeroni@gmail.com'),
(5, '15:49 - 13/10/2015', '15:50 - 13/10/2015', 'miltonmeroni@gmail.com'),
(6, '15:52 - 13/10/2015', '15:58 - 13/10/2015', 'miltonmeroni@gmail.com'),
(7, '15:52 - 13/10/2015', '15:58 - 13/10/2015', 'miltonmeroni@gmail.com'),
(8, '17:5 - 13/10/2015', '15:58 - 13/10/2015', 'miltonmeroni@gmail.com'),
(12, '16:01 - 13/10/2015', '16:01 - 13/10/2015', 'gastonbezzi@gmail.com'),
(13, '17:16 - 13/10/2015', '17:20 - 13/10/2015', 'ppsgalileo@gmail.com'),
(15, '17:23 - 13/10/2015', '17:23 - 13/10/2015', 'gastonbezzi@gmail.com'),
(16, '17:23 - 13/10/2015', '17:23 - 13/10/2015', 'gastonmaron@gmail.com'),
(17, '17:46 - 13/10/2015', '17:46 - 13/10/2015', 'miltonmeroni77@hotmail.com'),
(18, '18:02 - 13/10/2015', '18:03 - 13/10/2015', 'ppsgalileo@gmail.com'),
(19, '18:02 - 13/10/2015', '18:02 - 13/10/2015', 'gastonbezzi@gmail.com'),
(20, '18:03 - 13/10/2015', '18:03 - 13/10/2015', 'ppsgalileo@gmail.com'),
(21, '18:03 - 13/10/2015', '18:03 - 13/10/2015', 'ppsgalileo@gmail.com'),
(22, '18:03 - 13/10/2015', '18:04 - 13/10/2015', 'ppsgalileo@gmail.com'),
(23, '18:13 - 13/10/2015', '18:13 - 13/10/2015', 'gastonmaron@gmail.com'),
(24, '19:35 - 13/10/2015', '19:36 - 13/10/2015', 'ppsgalileo@gmail.com'),
(25, '19:37 - 13/10/2015', '19:39 - 13/10/2015', 'ppsgalileo@gmail.com'),
(26, '19:39 - 13/10/2015', '19:39 - 13/10/2015', 'ppsgalileo@gmail.com'),
(27, '19:39 - 13/10/2015', '19:42 - 13/10/2015', 'ppsgalileo@gmail.com'),
(28, '19:42 - 13/10/2015', '19:42 - 13/10/2015', 'ppsgalileo@gmail.com'),
(29, '19:43 - 13/10/2015', '19:43 - 13/10/2015', 'ppsgalileo@gmail.com'),
(30, '19:44 - 13/10/2015', '19:45 - 13/10/2015', 'ppsgalileo@gmail.com'),
(31, '19:45 - 13/10/2015', '19:45 - 13/10/2015', 'ppsgalileo@gmail.com'),
(32, '19:45 - 13/10/2015', '19:46 - 13/10/2015', 'ppsgalileo@gmail.com'),
(33, '19:46 - 13/10/2015', '19:47 - 13/10/2015', 'ppsgalileo@gmail.com'),
(34, '19:48 - 13/10/2015', '19:50 - 13/10/2015', 'ppsgalileo@gmail.com'),
(35, '19:58 - 13/10/2015', '19:59 - 13/10/2015', 'ppsgalileo@gmail.com'),
(36, '19:59 - 13/10/2015', '20:01 - 13/10/2015', 'ppsgalileo@gmail.com'),
(37, '20:01 - 13/10/2015', '20:01 - 13/10/2015', 'ppsgalileo@gmail.com'),
(38, '20:01 - 13/10/2015', '20:02 - 13/10/2015', 'ppsgalileo@gmail.com'),
(39, '20:02 - 13/10/2015', '20:02 - 13/10/2015', 'ppsgalileo@gmail.com'),
(40, '20:02 - 13/10/2015', '20:03 - 13/10/2015', 'ppsgalileo@gmail.com'),
(41, '20:03 - 13/10/2015', '20:04 - 13/10/2015', 'ppsgalileo@gmail.com'),
(42, '20:04 - 13/10/2015', '20:05 - 13/10/2015', 'ppsgalileo@gmail.com'),
(43, '20:05 - 13/10/2015', '20:05 - 13/10/2015', 'ppsgalileo@gmail.com'),
(44, '20:05 - 13/10/2015', '20:06 - 13/10/2015', 'ppsgalileo@gmail.com'),
(45, '20:06 - 13/10/2015', '20:06 - 13/10/2015', 'ppsgalileo@gmail.com'),
(46, '20:06 - 13/10/2015', '20:06 - 13/10/2015', 'ppsgalileo@gmail.com'),
(47, '20:07 - 13/10/2015', '20:07 - 13/10/2015', 'ppsgalileo@gmail.com'),
(48, '20:07 - 13/10/2015', '20:07 - 13/10/2015', 'ppsgalileo@gmail.com'),
(49, '20:08 - 13/10/2015', '20:08 - 13/10/2015', 'ppsgalileo@gmail.com'),
(50, '20:08 - 13/10/2015', '20:08 - 13/10/2015', 'ppsgalileo@gmail.com'),
(51, '20:10 - 13/10/2015', '20:10 - 13/10/2015', 'ppsgalileo@gmail.com'),
(52, '20:11 - 13/10/2015', '20:11 - 13/10/2015', 'ppsgalileo@gmail.com'),
(53, '20:12 - 13/10/2015', '20:12 - 13/10/2015', 'ppsgalileo@gmail.com'),
(54, '20:12 - 13/10/2015', '20:12 - 13/10/2015', 'ppsgalileo@gmail.com'),
(55, '20:12 - 13/10/2015', '20:13 - 13/10/2015', 'ppsgalileo@gmail.com'),
(56, '20:13 - 13/10/2015', '20:13 - 13/10/2015', 'ppsgalileo@gmail.com'),
(57, '20:15 - 13/10/2015', '20:15 - 13/10/2015', 'ppsgalileo@gmail.com'),
(58, '20:16 - 13/10/2015', '20:16 - 13/10/2015', 'ppsgalileo@gmail.com'),
(59, '8:57 - 14/10/2015', '8:58 - 14/10/2015', 'miltonmeroni@gmail.com'),
(60, '9:21 - 14/10/2015', '9:22 - 14/10/2015', 'ppsgalileo@gmail.com'),
(61, '9:22 - 14/10/2015', '9:23 - 14/10/2015', 'ppsgalileo@gmail.com'),
(62, '9:23 - 14/10/2015', '9:23 - 14/10/2015', 'ppsgalileo@gmail.com'),
(63, '9:23 - 14/10/2015', '9:24 - 14/10/2015', 'ppsgalileo@gmail.com'),
(64, '9:24 - 14/10/2015', '9:25 - 14/10/2015', 'ppsgalileo@gmail.com'),
(65, '9:25 - 14/10/2015', '9:26 - 14/10/2015', 'ppsgalileo@gmail.com'),
(66, '9:26 - 14/10/2015', '9:26 - 14/10/2015', 'ppsgalileo@gmail.com'),
(67, '9:26 - 14/10/2015', '9:27 - 14/10/2015', 'gastonmaron@gmail.com'),
(68, '9:27 - 14/10/2015', '9:27 - 14/10/2015', 'ppsgalileo@gmail.com'),
(69, '9:27 - 14/10/2015', '9:27 - 14/10/2015', 'gastonmaron@gmail.com'),
(70, '9:27 - 14/10/2015', '9:27 - 14/10/2015', 'ppsgalileo@gmail.com'),
(71, '9:27 - 14/10/2015', '9:27 - 14/10/2015', 'miltonmeroni@gmail.com'),
(72, '9:28 - 14/10/2015', '9:28 - 14/10/2015', 'ppsgalileo@gmail.com'),
(73, '10:38 - 14/10/2015', '10:38 - 14/10/2015', 'ppsgalileo@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
`id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `apellido` varchar(255) NOT NULL,
  `dni` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `temp` varchar(255) NOT NULL,
  `luz` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `email`, `password`, `temp`, `luz`) VALUES
(1, 'Administrador', 'Admin', '12345678', 'ppsgalileo@gmail.com', '1234', '25', '65'),
(3, 'Gaston', 'Bezzi', '12345687', 'gastonbezzi@gmail.com', '1992', '28', '70'),
(4, 'Milton', 'Meroni', '35798492', 'miltonmeroni@gmail.com', '5432', '18', '50'),
(7, 'Gaston', 'Maron', '36996998', 'gastonmaron@gmail.com', '4321', '24', '50'),
(8, 'Milton', 'Meroni', '35798492', 'miltonmeroni77@hotmail.com', '5847', '27', '50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auditoria`
--
ALTER TABLE `auditoria`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auditoria`
--
ALTER TABLE `auditoria`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
